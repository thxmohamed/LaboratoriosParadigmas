Este es el repositorio en el que iré desarrollando el
laboratorio 1 de paradigmas de programación, enfocado
a la aplicación del paradigma funcional implementado en
Racket.

Los scripts de pruebas son los archivos prueba1, prueba2
y prueba3.

El script de prueba1, al ser similar al 2, fue modificado.

Es importante decir que el RF12 no funciona con números, solo
con palabras claves.

El archivo main contiene todos los requisitos funcionales

El user está implementado como un elemento dentro del TDA System