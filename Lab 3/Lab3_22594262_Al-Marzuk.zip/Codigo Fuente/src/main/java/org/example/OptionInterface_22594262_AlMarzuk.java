package org.example;

import java.util.List;

public interface OptionInterface_22594262_AlMarzuk {
    public int optionGetID();
    public String optionGetMsg();
    public int optionGetChatbotID();
    public int optionGetFlowID();
    public List<String> optionGetKeywords();
}
