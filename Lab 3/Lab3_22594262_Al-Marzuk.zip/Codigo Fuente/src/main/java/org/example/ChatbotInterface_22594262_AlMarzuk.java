package org.example;
import java.util.List;

public interface ChatbotInterface_22594262_AlMarzuk {
    public void chatbotAddFlow(Flow_22594262_AlMarzuk flow);
    public void deleteFlow(int flowID);
    public Flow_22594262_AlMarzuk chatbotFindFlow(int FlowID);
}
